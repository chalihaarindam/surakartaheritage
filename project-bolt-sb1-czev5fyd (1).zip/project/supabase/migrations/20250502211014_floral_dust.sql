/*
  # Create tickets table for heritage site visitors

  1. New Tables
    - `tickets`
      - `id` (uuid, primary key) - Unique ticket identifier
      - `visitor_type` (text) - Local or international visitor
      - `age_group` (text, nullable) - Child, adult, or elderly
      - `gender` (text, nullable) - Male, female, or other
      - `timestamp` (timestamptz) - When the ticket was issued
      - `created_at` (timestamptz) - Record creation timestamp
      - `updated_at` (timestamptz) - Record last update timestamp

  2. Security
    - Enable RLS on tickets table
    - Add policies for authenticated staff members to:
      - Read all tickets
      - Create new tickets
      - Update tickets they created
*/

-- Create tickets table
CREATE TABLE IF NOT EXISTS tickets (
  id uuid PRIMARY KEY,
  visitor_type text NOT NULL CHECK (visitor_type IN ('local', 'international')),
  age_group text CHECK (age_group IN ('child', 'adult', 'elderly')),
  gender text CHECK (gender IN ('male', 'female', 'other')),
  timestamp timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE tickets ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Staff can read all tickets"
  ON tickets
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Staff can create tickets"
  ON tickets
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Staff can update tickets"
  ON tickets
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER tickets_updated_at
  BEFORE UPDATE ON tickets
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();