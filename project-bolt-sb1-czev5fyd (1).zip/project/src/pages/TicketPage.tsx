import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getTicket } from '../utils/db';
import { Ticket } from '../utils/db';
import TicketDisplay from '../components/TicketDisplay';
import { ArrowLeft, AlertTriangle } from 'lucide-react';

const TicketPage: React.FC = () => {
  const { ticketId } = useParams<{ ticketId: string }>();
  const [ticket, setTicket] = useState<Ticket | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchTicket = async () => {
      if (!ticketId) {
        setError('Invalid ticket ID');
        setLoading(false);
        return;
      }

      try {
        const result = await getTicket(ticketId);
        
        if (result) {
          setTicket(result);
        } else {
          setError('Ticket not found');
        }
      } catch (err) {
        console.error('Error fetching ticket:', err);
        setError('Failed to load ticket');
      } finally {
        setLoading(false);
      }
    };

    fetchTicket();
  }, [ticketId]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error || !ticket) {
    return (
      <div className="text-center py-12">
        <div className="bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 p-4 rounded-lg inline-flex items-center mb-6">
          <AlertTriangle className="w-6 h-6 mr-2" />
          <span>{error || 'Ticket not found'}</span>
        </div>
        
        <div className="mt-6">
          <Link to="/" className="btn-primary">
            Return to Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <Link to="/" className="inline-flex items-center text-primary hover:underline">
          <ArrowLeft className="w-4 h-4 mr-1" />
          <span>Back to Form</span>
        </Link>
      </div>
      
      <div className="text-center mb-8">
        <h1 className="text-2xl font-bold text-primary sm:text-3xl">
          Ticket Generated
        </h1>
        <p className="mt-2 text-gray-600 dark:text-gray-300">
          The ticket has been successfully created and saved locally.
        </p>
      </div>
      
      <TicketDisplay ticket={ticket} />
    </div>
  );
};

export default TicketPage;