import React from 'react';
import TicketForm from '../components/TicketForm';

const HomePage: React.FC = () => {
  return (
    <div className="flex flex-col items-center space-y-8">
      <div className="text-center max-w-2xl">
        <h1 className="text-3xl font-bold text-primary sm:text-4xl">
          Surakarta Heritage Ticketing
        </h1>
        <p className="mt-4 text-gray-600 dark:text-gray-300">
          Issue tickets for visitors to Surakarta's heritage sites. 
          Works offline with automatic syncing when connection is available.
        </p>
      </div>
      
      <TicketForm />
    </div>
  );
};

export default HomePage;