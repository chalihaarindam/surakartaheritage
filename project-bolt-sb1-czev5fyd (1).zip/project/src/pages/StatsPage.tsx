import React, { useEffect, useState } from 'react';
import { getStats } from '../utils/db';
import { BarChart2, Users, Globe, Clock } from 'lucide-react';

interface Stats {
  total: number;
  local: number;
  international: number;
  ageGroups: {
    child: number;
    adult: number;
    elderly: number;
  };
  genders: {
    male: number;
    female: number;
    other: number;
  };
  today: number;
}

const StatsPage: React.FC = () => {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const data = await getStats();
        setStats(data);
      } catch (error) {
        console.error('Error fetching stats:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600 dark:text-gray-300">
          Failed to load statistics. Please try again later.
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-primary sm:text-4xl flex items-center justify-center gap-2">
          <BarChart2 className="w-8 h-8" />
          <span>Visitor Statistics</span>
        </h1>
        <p className="mt-4 text-gray-600 dark:text-gray-300">
          Overview of tickets issued at Surakarta Heritage Site
        </p>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          title="Total Visitors"
          value={stats.total}
          icon={<Users className="w-6 h-6 text-blue-500" />}
          colorClass="bg-blue-50 dark:bg-blue-900/20"
        />
        <StatCard
          title="Local Visitors"
          value={stats.local}
          icon={<Users className="w-6 h-6 text-green-500" />}
          colorClass="bg-green-50 dark:bg-green-900/20"
        />
        <StatCard
          title="International"
          value={stats.international}
          icon={<Globe className="w-6 h-6 text-purple-500" />}
          colorClass="bg-purple-50 dark:bg-purple-900/20"
        />
        <StatCard
          title="Today"
          value={stats.today}
          icon={<Clock className="w-6 h-6 text-amber-500" />}
          colorClass="bg-amber-50 dark:bg-amber-900/20"
        />
      </div>

      {/* Age Groups */}
      <div className="card mb-8">
        <div className="p-5 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-semibold">Age Group Distribution</h2>
        </div>
        <div className="p-5">
          <div className="flex flex-col space-y-4">
            <BarStat 
              label="Child" 
              value={stats.ageGroups.child} 
              total={stats.total} 
              colorClass="bg-emerald-500" 
            />
            <BarStat 
              label="Adult" 
              value={stats.ageGroups.adult} 
              total={stats.total} 
              colorClass="bg-blue-500" 
            />
            <BarStat 
              label="Elderly" 
              value={stats.ageGroups.elderly} 
              total={stats.total} 
              colorClass="bg-amber-500" 
            />
          </div>
        </div>
      </div>

      {/* Gender Distribution */}
      <div className="card">
        <div className="p-5 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-semibold">Gender Distribution</h2>
        </div>
        <div className="p-5">
          <div className="flex flex-col space-y-4">
            <BarStat 
              label="Male" 
              value={stats.genders.male} 
              total={stats.total} 
              colorClass="bg-blue-500" 
            />
            <BarStat 
              label="Female" 
              value={stats.genders.female} 
              total={stats.total} 
              colorClass="bg-pink-500" 
            />
            <BarStat 
              label="Other" 
              value={stats.genders.other} 
              total={stats.total} 
              colorClass="bg-purple-500" 
            />
          </div>
        </div>
      </div>
    </div>
  );
};

interface StatCardProps {
  title: string;
  value: number;
  icon: React.ReactNode;
  colorClass: string;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon, colorClass }) => (
  <div className="card">
    <div className="p-5 flex items-center">
      <div className={`w-12 h-12 rounded-full flex items-center justify-center ${colorClass}`}>
        {icon}
      </div>
      <div className="ml-4">
        <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">{title}</h3>
        <p className="text-2xl font-semibold">{value}</p>
      </div>
    </div>
  </div>
);

interface BarStatProps {
  label: string;
  value: number;
  total: number;
  colorClass: string;
}

const BarStat: React.FC<BarStatProps> = ({ label, value, total, colorClass }) => {
  const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
  
  return (
    <div>
      <div className="flex justify-between mb-1">
        <span className="text-sm font-medium">{label}</span>
        <span className="text-sm font-medium">{value} ({percentage}%)</span>
      </div>
      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
        <div 
          className={`h-2.5 rounded-full ${colorClass}`} 
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
    </div>
  );
};

export default StatsPage;