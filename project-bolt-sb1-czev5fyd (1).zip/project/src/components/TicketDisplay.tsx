import React from 'react';
import QRCode from 'qrcode.react';
import { Ticket } from '../utils/db';
import { Calendar, MapPin, User } from 'lucide-react';

interface TicketDisplayProps {
  ticket: Ticket;
}

const TicketDisplay: React.FC<TicketDisplayProps> = ({ ticket }) => {
  const formattedDate = new Date(ticket.timestamp).toLocaleString();
  
  // Generate QR content - include all ticket data in JSON format
  const qrContent = JSON.stringify({
    id: ticket.id,
    type: ticket.visitorType,
    issued: formattedDate,
    venue: 'Surakarta Heritage Site'
  });
  
  return (
    <div className="max-w-md w-full mx-auto p-2">
      <div className="card overflow-hidden">
        {/* Ticket header */}
        <div className="bg-primary p-4 text-white text-center relative overflow-hidden">
          <div className="relative z-10">
            <h3 className="text-xl font-bold">Surakarta Heritage</h3>
            <p className="text-white/80">Visitor Ticket</p>
          </div>
          
          {/* Decorative pattern */}
          <div className="absolute inset-0 opacity-10 batik-bg"></div>
        </div>
        
        {/* Ticket body */}
        <div className="bg-white dark:bg-gray-800 p-6 flex flex-col items-center">
          {/* QR Code */}
          <div className="mb-6 p-2 bg-white rounded-lg shadow-inner">
            <QRCode
              value={qrContent}
              size={180}
              level="H"
              renderAs="svg"
              includeMargin={true}
              className="mx-auto"
            />
          </div>
          
          {/* Ticket ID */}
          <p className="text-center font-mono text-sm mb-4 px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded">
            {ticket.id.substring(0, 8).toUpperCase()}
          </p>
          
          {/* Ticket Info */}
          <div className="w-full space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <MapPin className="w-5 h-5 text-primary" />
                <span className="text-sm font-medium">Visitor Type:</span>
              </div>
              <span className="font-semibold capitalize">{ticket.visitorType}</span>
            </div>
            
            {ticket.ageGroup && (
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <User className="w-5 h-5 text-primary" />
                  <span className="text-sm font-medium">Age Group:</span>
                </div>
                <span className="font-semibold capitalize">{ticket.ageGroup}</span>
              </div>
            )}
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Calendar className="w-5 h-5 text-primary" />
                <span className="text-sm font-medium">Issued:</span>
              </div>
              <span className="text-sm">{formattedDate}</span>
            </div>
          </div>
        </div>
        
        {/* Ticket footer */}
        <div className="bg-gray-100 dark:bg-gray-700 p-4 text-center text-sm text-gray-600 dark:text-gray-300">
          <p>Please keep this ticket with you during your visit</p>
        </div>
      </div>
      
      <div className="mt-6 text-center">
        <button 
          onClick={() => window.print()} 
          className="btn-secondary inline-flex items-center space-x-2"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4" />
          </svg>
          <span>Print Ticket</span>
        </button>
      </div>
    </div>
  );
};

export default TicketDisplay;