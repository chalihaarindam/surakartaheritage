import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, Home, BarChart2, Sun, Moon } from 'lucide-react';
import { useThemeContext } from '../contexts/ThemeContext';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const { isDarkMode, toggleTheme } = useThemeContext();
  const location = useLocation();

  return (
    <header className="bg-primary/90 text-white shadow-md sticky top-0 z-10 backdrop-blur-sm">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-white/10">
              <Home className="w-6 h-6" />
            </div>
            <span className="text-xl font-semibold tracking-wide hidden sm:inline-block">
              Surakarta Heritage
            </span>
          </Link>
          
          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center space-x-6">
            <NavLink to="/" current={location.pathname === "/"}>
              Issue Ticket
            </NavLink>
            <NavLink to="/stats" current={location.pathname === "/stats"}>
              Statistics
            </NavLink>
            <button 
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-white/10 transition-colors"
              aria-label={isDarkMode ? "Switch to light mode" : "Switch to dark mode"}
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
          </nav>
          
          {/* Mobile menu button */}
          <div className="flex items-center space-x-3 md:hidden">
            <button 
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-white/10 transition-colors"
              aria-label={isDarkMode ? "Switch to light mode" : "Switch to dark mode"}
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 rounded-full hover:bg-white/10 transition-colors"
              aria-label="Toggle mobile menu"
            >
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-primary-dark shadow-lg animate-slideDown">
          <div className="container mx-auto px-4 py-3">
            <nav className="flex flex-col space-y-3">
              <MobileNavLink 
                to="/" 
                current={location.pathname === "/"} 
                onClick={() => setIsMenuOpen(false)}
              >
                Issue Ticket
              </MobileNavLink>
              <MobileNavLink 
                to="/stats" 
                current={location.pathname === "/stats"} 
                onClick={() => setIsMenuOpen(false)}
              >
                Statistics
              </MobileNavLink>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};

interface NavLinkProps {
  to: string;
  current: boolean;
  children: React.ReactNode;
}

const NavLink: React.FC<NavLinkProps> = ({ to, current, children }) => (
  <Link
    to={to}
    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
      current
        ? 'bg-white/20 text-white'
        : 'text-white/80 hover:bg-white/10 hover:text-white'
    }`}
  >
    {children}
  </Link>
);

interface MobileNavLinkProps extends NavLinkProps {
  onClick: () => void;
}

const MobileNavLink: React.FC<MobileNavLinkProps> = ({ to, current, onClick, children }) => (
  <Link
    to={to}
    className={`px-4 py-3 rounded-md text-base font-medium block transition-colors ${
      current
        ? 'bg-white/20 text-white'
        : 'text-white/80 hover:bg-white/10 hover:text-white'
    }`}
    onClick={onClick}
  >
    {children}
  </Link>
);

export default Header;