import React from 'react';
import { useSyncContext } from '../contexts/SyncContext';
import { Wifi, WifiOff, RefreshCw, Check, AlertTriangle } from 'lucide-react';

const SyncStatus: React.FC = () => {
  const { isOnline, syncStatus, pendingCount, syncData } = useSyncContext();

  // Show the status badge with different colors based on state
  return (
    <div className="fixed bottom-4 right-4 z-10">
      <div className="flex items-center space-x-2">
        {pendingCount > 0 && (
          <div className="text-xs bg-amber-100 dark:bg-amber-900 text-amber-800 dark:text-amber-100 px-2 py-1 rounded-full animate-pulse">
            {pendingCount} pending
          </div>
        )}
        
        <button
          onClick={() => syncData()}
          disabled={!isOnline || syncStatus === 'syncing'}
          className={`p-3 rounded-full shadow-lg flex items-center justify-center transition-colors ${
            getStatusClasses(isOnline, syncStatus)
          }`}
          aria-label={getAriaLabel(isOnline, syncStatus)}
        >
          {getStatusIcon(isOnline, syncStatus)}
        </button>
      </div>
    </div>
  );
};

// Helper functions to determine the appearance based on status
function getStatusClasses(isOnline: boolean, syncStatus: string): string {
  if (!isOnline) {
    return 'bg-red-600 text-white';
  }
  
  switch (syncStatus) {
    case 'syncing':
      return 'bg-amber-500 text-white animate-pulse';
    case 'success':
      return 'bg-emerald-500 text-white';
    case 'error':
      return 'bg-red-500 text-white';
    default:
      return 'bg-primary text-white hover:bg-primary-dark';
  }
}

function getStatusIcon(isOnline: boolean, syncStatus: string): React.ReactNode {
  if (!isOnline) {
    return <WifiOff className="w-5 h-5" />;
  }
  
  switch (syncStatus) {
    case 'syncing':
      return <RefreshCw className="w-5 h-5 animate-spin" />;
    case 'success':
      return <Check className="w-5 h-5" />;
    case 'error':
      return <AlertTriangle className="w-5 h-5" />;
    default:
      return <Wifi className="w-5 h-5" />;
  }
}

function getAriaLabel(isOnline: boolean, syncStatus: string): string {
  if (!isOnline) {
    return 'Offline - Cannot sync';
  }
  
  switch (syncStatus) {
    case 'syncing':
      return 'Syncing data...';
    case 'success':
      return 'Sync completed successfully';
    case 'error':
      return 'Sync error - Tap to retry';
    default:
      return 'Online - Tap to sync manually';
  }
}

export default SyncStatus;