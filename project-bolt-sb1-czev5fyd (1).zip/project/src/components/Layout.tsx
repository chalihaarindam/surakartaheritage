import React from 'react';
import Header from './Header';
import SyncStatus from './SyncStatus';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col batik-bg">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-6 sm:px-6 lg:px-8">
        {children}
      </main>
      <SyncStatus />
    </div>
  );
};

export default Layout;