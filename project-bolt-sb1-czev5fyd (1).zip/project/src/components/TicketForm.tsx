import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createTicket } from '../utils/db';
import { Users, UserRound, Calendar } from 'lucide-react';

const TicketForm: React.FC = () => {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    visitorType: 'local' as 'local' | 'international',
    ageGroup: '' as '' | 'child' | 'adult' | 'elderly',
    gender: '' as '' | 'male' | 'female' | 'other'
  });

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.visitorType) {
      return; // Require at least visitor type
    }
    
    try {
      setIsSubmitting(true);
      
      // Create ticket and get ID
      const ticketId = await createTicket(
        formData.visitorType,
        formData.ageGroup || undefined,
        formData.gender || undefined
      );
      
      // Navigate to the ticket display page
      navigate(`/ticket/${ticketId}`);
      
    } catch (error) {
      console.error('Error creating ticket:', error);
      setIsSubmitting(false);
      // Show error notification (could be expanded)
      alert('Failed to create ticket. Please try again.');
    }
  };

  return (
    <div className="card max-w-md w-full mx-auto p-6">
      <h2 className="text-2xl font-bold text-center mb-6 text-primary">Issue New Ticket</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Visitor Type - Required */}
        <div className="form-group">
          <label htmlFor="visitorType" className="form-label flex items-center gap-2">
            <Users className="w-5 h-5 text-primary" />
            <span>Visitor Type <span className="text-red-500">*</span></span>
          </label>
          <select
            id="visitorType"
            name="visitorType"
            value={formData.visitorType}
            onChange={handleChange}
            required
            className="form-select"
          >
            <option value="local">Local</option>
            <option value="international">International</option>
          </select>
        </div>
        
        {/* Age Group - Optional */}
        <div className="form-group">
          <label htmlFor="ageGroup" className="form-label flex items-center gap-2">
            <Calendar className="w-5 h-5 text-primary" />
            <span>Age Group <span className="text-gray-400">(optional)</span></span>
          </label>
          <select
            id="ageGroup"
            name="ageGroup"
            value={formData.ageGroup}
            onChange={handleChange}
            className="form-select"
          >
            <option value="">Select Age Group</option>
            <option value="child">Child</option>
            <option value="adult">Adult</option>
            <option value="elderly">Elderly</option>
          </select>
        </div>
        
        {/* Gender - Optional */}
        <div className="form-group">
          <label htmlFor="gender" className="form-label flex items-center gap-2">
            <UserRound className="w-5 h-5 text-primary" />
            <span>Gender <span className="text-gray-400">(optional)</span></span>
          </label>
          <select
            id="gender"
            name="gender"
            value={formData.gender}
            onChange={handleChange}
            className="form-select"
          >
            <option value="">Select Gender</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
        </div>
        
        <button
          type="submit"
          disabled={isSubmitting || !formData.visitorType}
          className={`btn-primary w-full flex items-center justify-center ${
            isSubmitting ? 'opacity-70 cursor-not-allowed' : ''
          }`}
        >
          {isSubmitting ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Processing...
            </>
          ) : (
            'Issue Ticket'
          )}
        </button>
      </form>
    </div>
  );
};

export default TicketForm;