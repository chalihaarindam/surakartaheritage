import Dexie, { Table } from 'dexie';
import { v4 as uuidv4 } from 'uuid';

// Define the interface for the ticket object
export interface Ticket {
  id: string;
  visitorType: 'local' | 'international';
  ageGroup?: 'child' | 'adult' | 'elderly';
  gender?: 'male' | 'female' | 'other';
  timestamp: number;
  synced: number; // 0 = not synced, 1 = synced
}

// Define the database
class TicketDatabase extends Dexie {
  tickets!: Table<Ticket>;

  constructor() {
    super('surakartaHeritage');
    this.version(1).stores({
      tickets: 'id, visitorType, ageGroup, gender, timestamp, synced'
    });
  }
}

export const db = new TicketDatabase();

// Function to create a new ticket
export const createTicket = async (
  visitorType: 'local' | 'international',
  ageGroup?: 'child' | 'adult' | 'elderly',
  gender?: 'male' | 'female' | 'other'
): Promise<string> => {
  const id = uuidv4();
  
  await db.tickets.add({
    id,
    visitorType,
    ageGroup,
    gender,
    timestamp: Date.now(),
    synced: 0 // Not synced initially
  });
  
  return id;
};

// Function to get a ticket by ID
export const getTicket = async (id: string): Promise<Ticket | undefined> => {
  return await db.tickets.get(id);
};

// Function to get all tickets
export const getAllTickets = async (): Promise<Ticket[]> => {
  return await db.tickets.toArray();
};

// Function to get stats
export const getStats = async () => {
  const tickets = await getAllTickets();
  
  const localCount = tickets.filter(t => t.visitorType === 'local').length;
  const internationalCount = tickets.filter(t => t.visitorType === 'international').length;
  
  const ageGroups = {
    child: tickets.filter(t => t.ageGroup === 'child').length,
    adult: tickets.filter(t => t.ageGroup === 'adult').length,
    elderly: tickets.filter(t => t.ageGroup === 'elderly').length,
  };
  
  const genders = {
    male: tickets.filter(t => t.gender === 'male').length,
    female: tickets.filter(t => t.gender === 'female').length,
    other: tickets.filter(t => t.gender === 'other').length,
  };
  
  // Get tickets issued today
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayTimestamp = today.getTime();
  const ticketsToday = tickets.filter(t => t.timestamp >= todayTimestamp).length;
  
  return {
    total: tickets.length,
    local: localCount,
    international: internationalCount,
    ageGroups,
    genders,
    today: ticketsToday
  };
};