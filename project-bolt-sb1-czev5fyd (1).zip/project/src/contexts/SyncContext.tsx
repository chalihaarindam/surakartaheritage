import React, { createContext, useContext, useState, useEffect } from 'react';
import { db } from '../utils/db';

interface SyncContextProps {
  isOnline: boolean;
  syncStatus: 'idle' | 'syncing' | 'success' | 'error';
  pendingCount: number;
  syncData: () => Promise<void>;
}

const SyncContext = createContext<SyncContextProps>({
  isOnline: navigator.onLine,
  syncStatus: 'idle',
  pendingCount: 0,
  syncData: async () => {},
});

export const useSyncContext = () => useContext(SyncContext);

export const SyncProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'success' | 'error'>('idle');
  const [pendingCount, setPendingCount] = useState(0);

  // Monitor online status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Count pending tickets
  useEffect(() => {
    const updatePendingCount = async () => {
      const count = await db.tickets.where('synced').equals(0).count();
      setPendingCount(count);
    };

    updatePendingCount();
    
    // Set up a timer to periodically check for pending tickets
    const interval = setInterval(updatePendingCount, 30000);
    
    return () => clearInterval(interval);
  }, []);

  // Sync data when connection becomes available
  useEffect(() => {
    if (isOnline && pendingCount > 0) {
      syncData();
    }
  }, [isOnline, pendingCount]);

  const syncData = async () => {
    if (!isOnline || syncStatus === 'syncing') return;
    
    try {
      setSyncStatus('syncing');
      
      // Get all unsynced tickets
      const unsynced = await db.tickets.where('synced').equals(0).toArray();
      
      if (unsynced.length === 0) {
        setSyncStatus('success');
        return;
      }
      
      // In a real app, you would POST this data to your server
      console.log('Syncing tickets:', unsynced);
      
      // Simulate API call with a delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mark as synced in local DB
      await Promise.all(
        unsynced.map(ticket => 
          db.tickets.update(ticket.id, { synced: 1 })
        )
      );
      
      // Update pending count
      setPendingCount(await db.tickets.where('synced').equals(0).count());
      setSyncStatus('success');
      
      // Reset status after a delay
      setTimeout(() => setSyncStatus('idle'), 3000);
      
    } catch (error) {
      console.error('Sync failed:', error);
      setSyncStatus('error');
      
      // Reset status after a delay
      setTimeout(() => setSyncStatus('idle'), 3000);
    }
  };

  return (
    <SyncContext.Provider value={{ isOnline, syncStatus, pendingCount, syncData }}>
      {children}
    </SyncContext.Provider>
  );
};